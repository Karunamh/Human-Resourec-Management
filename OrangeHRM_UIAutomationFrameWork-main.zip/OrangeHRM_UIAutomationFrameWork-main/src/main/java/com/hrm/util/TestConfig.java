package com.hrm.util;

public class TestConfig {
	
		public static final String Frist_Name = "Rajkumar";
		public static final String Employee_Frist_Name = "Pallavi";
		public static final String Supervisor_Name = "Yogiraj";
		public static final String Employee_Id = "0005";
		public static final String Middle_Name = "Shankar";
		public static final String Last_Name = "Dhoni";
		public static final String User_Name = "rajkumar";
		public static final String Password = "raj123";
		public static final String Confirm_Password = "raj123";
		public static final String Photograph = "D:\\OrangeHRM\\Dhoni.jpg";
		public static final String ReportName = "Msys Report";
		public static final String EditReportName = "Msys Report Edit";
		public static final String Employee_Name = "Pallavi Yadav";

	//Recruitment Page Test Config
		//Add Job Vacancies
		public static final String JOB_TITLE="Automation tester";
		public static final String VACANCY_NAME="Test Automation Lead";
		public static final String HIRING_MANAGER="Sagar Unbeg";
		public static final int NUMBER_OF_POSITIONS=3;
		public static final String JOB_DESCRIPTION="Job Details-\r\n" + 
				"Required Test Automation Lead\r\n" + 
				"Experience - 8-10 yrs";
		public static final String JOB_VACANCY_TO_DELETE="Test Automation Lead";
		public static final String VACANCYSEARCH_JOBTITLE="Automation tester";
		public static final String VACANCYSEARCH_JOBVACANCYNAME="Lead Automation tester";
		public static final String VACANCYSEARCH_STATUS="Active";
		public static final String VACANCYSEARCH_HIRINGMANAGER="Sagar Unbeg";
		
		//Modify Value
		public static final int UPDATED_NUMBER_OF_POSITIONS=7;
		public static final String UPDATED_CANDIDATE_CONTACT_NUMNBER="9879879878";
		
	//Candidate Page Information
		
		public static final String CANDIDATE_FIRST_NAME="Ramesh";
		public static final String CANDIDATE_MIDDDLE_NAME="Bharat";
		public static final String CANDIDATE_LAST_NAME="Trivedi";
		public static final String CANDIDATE_EMAIL="bharat.trivedi@gmail.com";
		public static final String CANDIDATE_CONTACT_NUMBER="1234567891";
		public static final String CANDIDATE_KEYWORDS="Core Java, Selenium Automaion- TestNG, Cucummber, Appium";
		public static final String CANDIDATE_COMMENT="Have 3 yr of experience in automation";
		public static final String CANDIDATE_JOBVACANCYNAME="Lead Automation tester";
		public static final String CANDIDATE_DATE_OF_APPLICATION="2017/07/13";
		public static final String CANDIDATE_FULL_NAME=CANDIDATE_FIRST_NAME+" "+CANDIDATE_MIDDDLE_NAME+" "+CANDIDATE_LAST_NAME;
		public static final String CANDIDATE_JOBTITLE="Automation tester";
		public static final String CANDIDATE_STATUS="Application Initiated";
		public static final String CANDIDATE_HIRINGMANAGER="Sagar Unbeg";
		public static final String CANDIDATE_DATE_OF_APPLICATION_FROM="2017/07/13";
		public static final String CANDIDATE_DATE_OF_APPLICATION_TO="2018/06/06";		
		
		
		
	// Testlink integration with eclipse
		 public static final String SERVER_URL = "http://192.168.102.26:81/testlink/lib/api/xmlrpc/v1/xmlrpc.php";
		 public static String API_KEY = "5946f39bee06f0ba104a1b7b6474dd77";
		 
		 public static final String PROJECT_NAME = "Msys_HRMS";
		 public static String TEST_PLAN_NAME = "Msys_HRMS";
		 public static String BUILD_NAME = "HRMSDemo";
		 
		 
		//Admin Tab
		 public static final String AdminUser_Name = "Msys123";
		
}